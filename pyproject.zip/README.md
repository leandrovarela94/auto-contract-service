# 🔒 PropostaAI — FastAPI + Static Page

Gerador local de propostas com IA. Backend **FastAPI**, frontend **HTML puro em `/static`** — sem Jinja2, sem templates, sem SSR.

---

## Estrutura

```
proposta-fastapi/
├── main.py              ← FastAPI app (rotas, Pydantic, lógica)
├── requirements.txt
├── README.md
└── static/
    └── index.html       ← SPA servida pelo StaticFiles
```

---

## Instalação

```bash
pip install -r requirements.txt
```

## Rodar

```bash
uvicorn main:app --host 127.0.0.1 --port 8000
```

Acesse: **http://127.0.0.1:8000**

Docs interativas (Swagger): **http://127.0.0.1:8000/docs**

---

## API Endpoints

| Método | Rota | Descrição |
|---|---|---|
| `GET` | `/` | Serve `static/index.html` |
| `POST` | `/api/analyze` | Upload PDF + detecção de variáveis |
| `POST` | `/api/calculate` | Recalcula campos derivados em tempo real |
| `POST` | `/api/generate` | Gera PDF preenchido (stream) |
| `POST` | `/api/market-ref/save` | Salva referências de mercado (RAM) |
| `POST` | `/api/market-ref/load` | Carrega referências pela senha |
| `POST` | `/api/session/clear` | Apaga sessão da RAM |

---

## Segurança

- Tudo em memória RAM — nada gravado em disco
- PDF gerado retornado como `StreamingResponse` direto
- Senhas armazenadas apenas como SHA-256
- `127.0.0.1` only — não exposto na rede

---

## Hot reload (dev)

```bash
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```
