"""
PropostaAI — FastAPI Backend
Todos os dados são processados localmente. Nenhum dado é armazenado em disco.
"""

from __future__ import annotations

import ast
import hashlib
import io
import json
import operator
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

import anthropic
import pdfplumber
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fpdf import FPDF
from pydantic import BaseModel, field_validator

# ─── App ──────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="PropostaAI",
    description="Gerador local de propostas com IA — dados apenas em memória RAM",
    version="2.0.0",
    docs_url="/docs",
    redoc_url=None,
)

STATIC_DIR = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# ─── Memória (nunca toca o disco) ─────────────────────────────────────────────

_sessions: dict[str, dict[str, Any]] = {}
_market_store: dict[str, dict[str, Any]] = {}  # {sha256(senha): refs}


# ─── Schemas Pydantic ─────────────────────────────────────────────────────────

class CalculateRequest(BaseModel):
    variables: dict[str, str]
    calculations: list[dict[str, Any]]


class GenerateRequest(BaseModel):
    session_id: str
    values: dict[str, str]
    calc_values: dict[str, Any] = {}
    title: str = "Proposta de Serviço"


class MarketRefSaveRequest(BaseModel):
    password: str
    references: dict[str, Any]

    @field_validator("password")
    @classmethod
    def password_min_length(cls, v: str) -> str:
        if len(v.strip()) < 4:
            raise ValueError("Senha deve ter no mínimo 4 caracteres")
        return v.strip()


class MarketRefLoadRequest(BaseModel):
    password: str


class SessionClearRequest(BaseModel):
    session_id: str


# ─── Utilitários ──────────────────────────────────────────────────────────────

def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def _format_value(value: float, type_: str) -> str:
    if type_ == "currency":
        return f"R$ {value:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    if type_ == "percentage":
        return f"{value:.2f}%"
    return f"{value:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def _safe_eval(formula: str, variables: dict[str, str]) -> float:
    """Avalia expressões matemáticas sem eval() direto."""
    _OPS: dict[type, Any] = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.Pow: operator.pow,
        ast.USub: operator.neg,
    }

    def _node(n: ast.expr) -> float:
        if isinstance(n, ast.Constant):
            return float(n.n)
        if isinstance(n, ast.Name):
            raw = variables.get(n.id, "0")
            cleaned = str(raw).replace(",", ".").replace("R$", "").replace(" ", "") or "0"
            return float(cleaned)
        if isinstance(n, ast.BinOp):
            fn = _OPS.get(type(n.op))
            if fn is None:
                raise ValueError(f"Operador não permitido: {type(n.op)}")
            return fn(_node(n.left), _node(n.right))
        if isinstance(n, ast.UnaryOp):
            fn = _OPS.get(type(n.op))
            if fn is None:
                raise ValueError("Operador unário não permitido")
            return fn(_node(n.operand))
        raise ValueError(f"Nó não suportado: {type(n)}")

    try:
        tree = ast.parse(formula, mode="eval")
        return _node(tree.body)
    except Exception:
        return 0.0


def _extract_text(pdf_bytes: bytes) -> str:
    text = ""
    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        for i, page in enumerate(pdf.pages):
            chunk = page.extract_text(x_tolerance=3, y_tolerance=3)
            if chunk:
                text += f"\n[PÁGINA {i + 1}]\n{chunk}\n"
    return text.strip()


def _build_pdf(content: str, title: str = "Proposta de Serviço") -> bytes:
    """Gera PDF profissional em memória e retorna os bytes."""
    pdf = FPDF()
    pdf.set_margins(20, 20, 20)
    pdf.set_auto_page_break(auto=True, margin=20)
    pdf.add_page()

    # cabeçalho azul-escuro
    pdf.set_fill_color(15, 23, 42)
    pdf.rect(0, 0, 210, 35, "F")
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("Helvetica", "B", 16)
    pdf.set_y(12)
    safe = lambda s: s.encode("latin-1", "replace").decode("latin-1")
    pdf.cell(0, 10, safe(title), align="C", ln=True)
    pdf.set_font("Helvetica", "", 9)
    pdf.cell(0, 5, f"Gerado em: {datetime.now().strftime('%d/%m/%Y às %H:%M')}", align="C", ln=True)
    pdf.set_y(45)
    pdf.set_text_color(15, 23, 42)

    for line in content.split("\n"):
        lc = safe(line)
        if line.startswith("# "):
            pdf.set_font("Helvetica", "B", 14)
            pdf.set_fill_color(241, 245, 249)
            pdf.cell(0, 8, lc[2:], ln=True, fill=True)
            pdf.ln(2)
        elif line.startswith("## "):
            pdf.set_font("Helvetica", "B", 12)
            pdf.set_text_color(59, 130, 246)
            pdf.cell(0, 7, lc[3:], ln=True)
            pdf.set_text_color(15, 23, 42)
            pdf.ln(1)
        elif line.startswith("### "):
            pdf.set_font("Helvetica", "B", 11)
            pdf.cell(0, 6, lc[4:], ln=True)
        elif line.startswith("---"):
            pdf.set_draw_color(203, 213, 225)
            pdf.line(20, pdf.get_y(), 190, pdf.get_y())
            pdf.ln(3)
        elif not line.strip():
            pdf.ln(3)
        elif "**" in lc:
            parts = lc.split("**")
            pdf.set_x(20)
            for j, part in enumerate(parts):
                pdf.set_font("Helvetica", "B" if j % 2 else "", 10)
                pdf.write(5, part)
            pdf.ln(5)
        else:
            pdf.set_font("Helvetica", "", 10)
            pdf.multi_cell(0, 5, lc)

    return bytes(pdf.output())


_ANALYSIS_PROMPT = """\
Você é um especialista em análise de documentos empresariais brasileiros.

Analise este documento de proposta/orçamento/contrato e identifique TODAS as variáveis personalizáveis.

Retorne APENAS JSON válido (sem markdown, sem texto antes ou depois):
{{
  "document_type": "tipo do documento em português",
  "sections": ["lista de seções identificadas"],
  "variables": [
    {{
      "id": "nome_em_snake_case",
      "label": "Nome Legível em Português",
      "description": "O que representa este campo",
      "type": "text|number|currency|date|percentage|email|phone",
      "current_value": "valor atual encontrado no texto, ou string vazia",
      "is_calculated": false,
      "formula": "",
      "category": "cliente|fornecedor|financeiro|servico|prazo|contato|outro",
      "required": true,
      "locked": false,
      "market_reference": null
    }}
  ],
  "calculations": [
    {{
      "id": "nome_calculo",
      "label": "Nome do Cálculo",
      "formula": "expressão usando ids das variáveis (ex: quantidade * preco_unitario)",
      "type": "currency|percentage|number",
      "description": "O que este cálculo representa"
    }}
  ]
}}

Diretrizes:
- Identifique campos: nome do cliente, CNPJ, endereço, valor do serviço, prazo, responsável, etc.
- Para campos financeiros extraia valores numéricos (sem R$, sem pontos de milhar)
- Identifique TODOS os cálculos: subtotal, impostos (ISS, PIS, COFINS), total, desconto, etc.

Documento:
{text}
"""

_FILL_PROMPT = """\
Você é um especialista em redação de propostas comerciais profissionais em português brasileiro.

Documento original (template):
{template}

Valores a inserir:
{values}

Gere o documento COMPLETO e PROFISSIONAL com todos os valores inseridos.
Use formatação Markdown (# título, ## seção, **negrito**, --- separador).

Regras:
1. Substitua TODOS os campos identificados pelos valores fornecidos
2. Formate valores monetários como R$ X.XXX,XX
3. Formate datas em dd/mm/aaaa
4. Mantenha tom profissional e formal
5. Inclua TODOS os cálculos (subtotais, impostos, total final)
6. NÃO adicione campos inexistentes no original

Retorne APENAS o documento formatado.
"""


# ─── Rotas ────────────────────────────────────────────────────────────────────

@app.get("/", include_in_schema=False)
async def root() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.post("/api/analyze")
async def analyze_pdf(
    file: UploadFile = File(...),
    api_key: str = Form(...),
    market_password: str = Form(""),
) -> dict[str, Any]:
    """Analisa o PDF com IA e detecta variáveis automaticamente."""

    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Apenas arquivos PDF são aceitos")

    if not api_key.strip():
        raise HTTPException(status_code=400, detail="Chave de API Anthropic é obrigatória")

    pdf_bytes = await file.read()

    try:
        text_content = _extract_text(pdf_bytes)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Falha ao extrair texto do PDF: {exc}")

    if not text_content.strip():
        raise HTTPException(
            status_code=400,
            detail="Não foi possível extrair texto. O PDF pode ser uma imagem escaneada.",
        )

    try:
        client = anthropic.Anthropic(api_key=api_key.strip())
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4000,
            messages=[{"role": "user", "content": _ANALYSIS_PROMPT.format(text=text_content[:5000])}],
        )
    except anthropic.AuthenticationError:
        raise HTTPException(status_code=401, detail="Chave de API inválida. Verifique em console.anthropic.com")
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Erro na API Anthropic: {exc}")

    raw = response.content[0].text.strip()
    if "```json" in raw:
        raw = raw.split("```json")[1].split("```")[0].strip()
    elif "```" in raw:
        raw = raw.split("```")[1].split("```")[0].strip()

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        raise HTTPException(status_code=500, detail="Resposta da IA em formato inesperado. Tente novamente.")

    # Aplicar referências de mercado se senha fornecida
    market_refs: dict[str, Any] = {}
    if market_password.strip():
        market_refs = _market_store.get(_sha256(market_password.strip()), {})

    variables = data.get("variables", [])
    for var in variables:
        if var["id"] in market_refs:
            ref = market_refs[var["id"]]
            var["market_reference"] = ref
            var["current_value"] = ref.get("value", var["current_value"])
            var["locked"] = ref.get("locked", False)

    # Guardar sessão em RAM
    session_id = str(uuid.uuid4())
    _sessions[session_id] = {
        "text_content": text_content,
        "variables": variables,
        "calculations": data.get("calculations", []),
        "document_type": data.get("document_type", "Proposta de Serviço"),
        "api_key": api_key.strip(),
    }

    return {
        "session_id": session_id,
        "document_type": data.get("document_type", "Proposta de Serviço"),
        "sections": data.get("sections", []),
        "variables": variables,
        "calculations": data.get("calculations", []),
        "text_preview": text_content[:500] + ("..." if len(text_content) > 500 else ""),
    }


@app.post("/api/calculate")
async def calculate_values(body: CalculateRequest) -> dict[str, Any]:
    """Recalcula todos os campos derivados em tempo real."""
    results: dict[str, Any] = {}
    for calc in body.calculations:
        try:
            value = _safe_eval(calc["formula"], body.variables)
            results[calc["id"]] = {
                "value": value,
                "formatted": _format_value(value, calc.get("type", "number")),
                "label": calc["label"],
            }
        except Exception as exc:
            results[calc["id"]] = {
                "value": 0,
                "formatted": "0",
                "label": calc.get("label", calc["id"]),
                "error": str(exc),
            }
    return {"calculations": results}


@app.post("/api/generate")
async def generate_document(body: GenerateRequest) -> StreamingResponse:
    """Gera o PDF final preenchido e retorna como stream (nunca salvo em disco)."""
    session = _sessions.get(body.session_id)
    if session is None:
        raise HTTPException(status_code=400, detail="Sessão não encontrada. Faça upload do PDF novamente.")

    all_values = dict(body.values)
    for cid, cdata in body.calc_values.items():
        all_values[cid] = cdata.get("formatted", str(cdata.get("value", 0)))

    values_str = "\n".join(f"- {k}: {v}" for k, v in all_values.items())

    try:
        client = anthropic.Anthropic(api_key=session["api_key"])
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4000,
            messages=[{
                "role": "user",
                "content": _FILL_PROMPT.format(
                    template=session["text_content"][:3000],
                    values=values_str,
                ),
            }],
        )
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Erro ao gerar conteúdo: {exc}")

    filled = response.content[0].text.strip()
    pdf_bytes = _build_pdf(filled, body.title)

    filename = f"proposta_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.post("/api/market-ref/save")
async def save_market_ref(body: MarketRefSaveRequest) -> dict[str, Any]:
    """Persiste referências de mercado em RAM protegidas por hash da senha."""
    _market_store[_sha256(body.password)] = body.references
    return {"success": True, "message": f"{len(body.references)} referência(s) salva(s) com sucesso"}


@app.post("/api/market-ref/load")
async def load_market_ref(body: MarketRefLoadRequest) -> dict[str, Any]:
    """Carrega referências de mercado pela senha."""
    refs = _market_store.get(_sha256(body.password.strip()))
    if refs is None:
        raise HTTPException(status_code=401, detail="Senha incorreta ou sem referências salvas")
    return {"success": True, "references": refs}


@app.post("/api/session/clear")
async def clear_session(body: SessionClearRequest) -> dict[str, bool]:
    """Remove dados da sessão da RAM imediatamente."""
    _sessions.pop(body.session_id, None)
    return {"success": True}
